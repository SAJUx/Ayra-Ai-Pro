package com.error.girlai.net

import org.json.JSONArray
import org.json.JSONObject

object GeminiClient {
    fun generate(apiKey: String, system: String, turns: List<Pair<String,String>>): String {
        val contents = JSONArray()
        contents.put(JSONObject().put("role","user").put("parts", JSONArray().put(JSONObject().put("text", system))))
        for ((role, text) in turns) {
            val r = if (role == "assistant") "model" else "user"
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        val body = JSONObject().put("contents", contents).toString()
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"

        val resp = Http.postJson(url, emptyMap(), body)
        resp.use {
            val s: String = it.body?.string() ?: ""
            if (!it.isSuccessful) throw RuntimeException("Gemini failed: ${it.code} $s")

            val obj = JSONObject(s)
            val candidates = obj.optJSONArray("candidates") ?: JSONArray()
            val cand0 = if (candidates.length() > 0) candidates.getJSONObject(0) else JSONObject()
            val content = cand0.optJSONObject("content") ?: JSONObject()
            val parts = content.optJSONArray("parts") ?: JSONArray()
            val p0 = if (parts.length() > 0) parts.getJSONObject(0) else JSONObject()
            return@use p0.optString("text","").trim()
        }.also { return it }
    }
}
