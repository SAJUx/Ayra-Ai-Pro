package com.error.girlai.net

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File

object OpenAISttClient {
    private val OCTET = "application/octet-stream".toMediaType()

    fun transcribe(apiKey: String, wavFile: File, language: String = "bn"): String {
        val form = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model", "gpt-4o-mini-transcribe")
            .addFormDataPart("language", language)
            .addFormDataPart("file", "audio.wav", wavFile.asRequestBody(OCTET))
            .build()

        val req = Request.Builder()
            .url("https://api.openai.com/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(form)
            .build()

        val call = Http.client.newCall(req)
        call.execute().use { resp ->
            val body: String = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw RuntimeException("STT failed: ${resp.code} $body")
            return JSONObject(body).optString("text", "").trim()
        }
    }
}
