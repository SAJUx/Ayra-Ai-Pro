package com.error.girlai.net

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody

object Http {
    val client: OkHttpClient = OkHttpClient()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun postJson(url: String, headers: Map<String, String>, json: String): okhttp3.Response {
        val body: RequestBody = json.toRequestBody(JSON)
        val builder = Request.Builder().url(url).post(body)
        for ((k, v) in headers) builder.addHeader(k, v)
        return client.newCall(builder.build()).execute()
    }
}
