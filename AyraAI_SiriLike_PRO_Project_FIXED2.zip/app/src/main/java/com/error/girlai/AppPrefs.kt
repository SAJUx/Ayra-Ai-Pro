package com.error.girlai

import android.content.Context

object AppPrefs {
    private const val PREF = "ayra_prefs"
    private const val KEY_PROVIDER = "provider"

    fun getProvider(context: Context): ProviderType {
        val v = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_PROVIDER, ProviderType.OPENAI.name)
        return try { ProviderType.valueOf(v ?: ProviderType.OPENAI.name) } catch (_: Throwable) { ProviderType.OPENAI }
    }

    fun setProvider(context: Context, provider: ProviderType) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY_PROVIDER, provider.name).apply()
    }
}
