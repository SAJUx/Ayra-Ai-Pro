package com.error.girlai.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.*
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.error.girlai.AppPrefs
import com.error.girlai.ProviderType
import com.error.girlai.R
import com.error.girlai.net.GeminiClient
import com.error.girlai.net.OpenAIClient
import com.error.girlai.net.OpenAISttClient
import com.error.girlai.net.OpenAITtsClient
import com.error.girlai.store.KeyStore
import com.error.girlai.store.MemoryStore
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

class AyraVoiceService : Service() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var recorder: AudioRecord? = null
    private var running = false

    private val sampleRate = 16000
    private val channel = AudioFormat.CHANNEL_IN_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(11, buildNotification("Ayra listening (wake: Ayra/আয়রা)"))
        startLoop()
    }

    override fun onDestroy() {
        super.onDestroy()
        running = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        scope.cancel()
    }

    private fun buildNotification(text: String): Notification {
        val chId = "ayra_voice"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(chId, "Ayra Voice", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
        val stopIntent = Intent(this, AyraVoiceService::class.java).apply { action = "STOP" }
        val stopPI = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, chId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Ayra")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "Stop", stopPI)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startLoop() {
        if (running) return
        running = true

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channel, encoding).coerceAtLeast(sampleRate)
        recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate, channel, encoding, minBuf)
        recorder?.startRecording()

        scope.launch(Dispatchers.IO) {
            val buf = ShortArray(minBuf / 2)
            val outDir = File(cacheDir, "ayra_audio").apply { mkdirs() }

            val rmsThreshold = 700.0     // lower = more sensitive (low voice)
            val speechMinMs = 650L
            val silenceEndMs = 650L

            var speaking = false
            var lastVoiceTs = 0L
            var startSpeechTs = 0L
            val pcm = ArrayList<Short>(sampleRate * 5)

            while (running) {
                val r = recorder?.read(buf, 0, buf.size) ?: 0
                if (r <= 0) continue

                var sum = 0.0
                for (i in 0 until r) {
                    val v = buf[i].toInt()
                    sum += (v * v).toDouble()
                }
                val rms = sqrt(sum / r)
                val now = System.currentTimeMillis()
                val voiced = rms > rmsThreshold

                if (voiced) {
                    lastVoiceTs = now
                    if (!speaking) {
                        speaking = true
                        startSpeechTs = now
                        pcm.clear()
                    }
                }

                if (speaking) {
                    for (i in 0 until r) pcm.add(buf[i])
                    val speechLen = now - startSpeechTs
                    val silence = now - lastVoiceTs

                    if (speechLen >= speechMinMs && silence >= silenceEndMs) {
                        speaking = false
                        val wav = File(outDir, "in.wav")
                        writeWav16kMono(wav, pcm.toShortArray())

                        try {
                            val openAiKey = KeyStore.getApiKey(this@AyraVoiceService)
                            if (openAiKey.isBlank()) continue

                            val text = OpenAISttClient.transcribe(openAiKey, wav, "bn")
                            if (text.isBlank()) continue

                            val woke = text.contains("Ayra", true) || text.contains("আয়রা") || text.contains("আইরা")
                            if (!woke) continue

                            val cleaned = text.replace("Ayra", "", true).replace("আয়রা","").replace("আইরা","").trim()
                            if (cleaned.isBlank()) continue

                            MemoryStore.append(this@AyraVoiceService, "user", cleaned)
                            val turns = MemoryStore.load(this@AyraVoiceService).map { it.role to it.content }
                            val system = "You are Ayra, a Bengali voice assistant. Reply in Bangla, very short, fast, and helpful. Light humor ok."

                            val provider = AppPrefs.getProvider(this@AyraVoiceService)
                            val reply = when (provider) {
                                ProviderType.GEMINI -> {
                                    val gKey = KeyStore.getGeminiKey(this@AyraVoiceService)
                                    if (gKey.isBlank()) OpenAIClient.respond(openAiKey, "gpt-4o-mini", system, turns)
                                    else GeminiClient.generate(gKey, system, turns)
                                }
                                else -> OpenAIClient.respond(openAiKey, "gpt-4o-mini", system, turns)
                            }

                            MemoryStore.append(this@AyraVoiceService, "assistant", reply)

                            val mp3 = File(outDir, "out.mp3")
                            OpenAITtsClient.speakToFile(openAiKey, reply, mp3, voice = "alloy")
                            playMp3(mp3)

                        } catch (_: Throwable) {
                            // ignore and continue
                        }
                    }
                }
            }
        }
    }

    private fun playMp3(file: File) {
        try {
            val player = MediaPlayer()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            player.setDataSource(file.absolutePath)
            player.setOnCompletionListener { it.release() }
            player.prepare()
            player.start()
        } catch (_: Throwable) {}
    }

    private fun writeWav16kMono(out: File, pcm: ShortArray) {
        val dataLen = pcm.size * 2
        val totalLen = 36 + dataLen
        val byteRate = sampleRate * 2

        FileOutputStream(out).use { fos ->
            fun w(s: String) = fos.write(s.toByteArray())
            fun wi(v: Int) { fos.write(byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte(), ((v shr 16) and 0xff).toByte(), ((v shr 24) and 0xff).toByte())) }
            fun ws(v: Int) { fos.write(byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte())) }

            w("RIFF"); wi(totalLen); w("WAVE")
            w("fmt "); wi(16); ws(1); ws(1); wi(sampleRate); wi(byteRate); ws(2); ws(16)
            w("data"); wi(dataLen)

            val bb = ByteArray(dataLen)
            var idx = 0
            for (s in pcm) {
                bb[idx++] = (s.toInt() and 0xff).toByte()
                bb[idx++] = ((s.toInt() shr 8) and 0xff).toByte()
            }
            fos.write(bb)
        }
    }
}
