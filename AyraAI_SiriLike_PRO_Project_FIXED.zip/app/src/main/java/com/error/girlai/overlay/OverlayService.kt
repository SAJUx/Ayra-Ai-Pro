package com.error.girlai.overlay

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.error.girlai.R
import com.error.girlai.net.OpenAIClient
import com.error.girlai.store.KeyStore
import com.error.girlai.store.MemoryStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 1001
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var monitorRunning = false

    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null

    private val scope = CoroutineScope(Dispatchers.Main)
    private var unlockReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) {
            tts?.language = Locale("bn", "BD")
        }
        speech = SpeechRecognizer.createSpeechRecognizer(this)

        unlockReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_USER_PRESENT) {
                    tts?.speak("Sir, আমি আয়রা। আপনার জন্য কী করতে পারি?", TextToSpeech.QUEUE_FLUSH, null, "unlock")
                }
            }
        }
        try {
            registerReceiver(unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT))
        } catch (_: Throwable) { }

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startOverlay()
            ACTION_STOP -> stopOverlay()
            else -> startOverlay()
        }
        return START_STICKY
    }

    private fun startOverlay() {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        if (monitorRunning) return
        monitorRunning = true
        handler.post(monitorRunnable)
        Toast.makeText(this, "Home-only animated avatar ✅", Toast.LENGTH_SHORT).show()
    }

    private val monitorRunnable = object : Runnable {
        override fun run() {
            val onHome = isOnHomeScreen()
            if (onHome) {
                if (overlayView == null) showOverlayInternal()
            } else {
                if (overlayView != null) hideOverlayInternal()
            }
            if (monitorRunning) handler.postDelayed(this, 900)
        }
    }

    private fun showOverlayInternal() {
        if (overlayView != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        overlayView = inflater.inflate(R.layout.overlay_avatar, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 200
        }

        val avatar = overlayView!!.findViewById<ImageView>(R.id.avatarImage)

        // Frame animation (PNG)
        avatar.setBackgroundResource(R.drawable.avatar_anim)
        (avatar.background as? AnimationDrawable)?.start()

        avatar.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var lastTap = 0L

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x
                        initialY = p.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = initialX + (event.rawX - initialTouchX).toInt()
                        p.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(overlayView, p)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = kotlin.math.abs(event.rawX - initialTouchX)
                        val dy = kotlin.math.abs(event.rawY - initialTouchY)
                        val now = System.currentTimeMillis()
                        if (dx < 15 && dy < 15 && now - lastTap > 450) {
                            lastTap = now
                            startListeningOnce()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager?.addView(overlayView, params)
    }

    private fun hideOverlayInternal() {
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
    }

    private fun stopOverlay() {
        monitorRunning = false
        handler.removeCallbacks(monitorRunnable)
        hideOverlayInternal()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopOverlay()
        speech?.destroy()
        tts?.shutdown()
        try { unlockReceiver?.let { unregisterReceiver(it) } } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Ayra AI")
            .setContentText("Home-only animated avatar is running")
            .setOngoing(true)
            .build()
    }

    private fun getDefaultHomePackage(): String? {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolveInfo?.activityInfo?.packageName
    }

    private fun isOnHomeScreen(): Boolean {
        val homePkg = getDefaultHomePackage() ?: return false

        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - 10_000

        val events = usm.queryEvents(begin, end)
        val event = UsageEvents.Event()
        var lastPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastPkg = event.packageName
            }
        }

        return (lastPkg == null) || (lastPkg == homePkg)
    }

    private fun startListeningOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "বলুন…", Toast.LENGTH_SHORT).show()
        tts?.speak("বলুন", TextToSpeech.QUEUE_FLUSH, null, "say")

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        }

        speech?.setRecognitionListener(SimpleRecognitionListener(
            onResult = { userText ->
                val saidWake = userText.contains("Ayra", ignoreCase = true) ||
                        userText.contains("আয়রা") || userText.contains("আইরা") || userText.contains("এরা")
                if (!saidWake) {
                    Toast.makeText(this@OverlayService, "নাম ধরে ডাকুন: Ayra / আয়রা", Toast.LENGTH_SHORT).show()
                } else {
                MemoryStore.append(this@OverlayService, "user", userText)

                scope.launch {
                    val apiKey = KeyStore.getApiKey(this@OverlayService)
                    if (apiKey.isBlank()) {
                        Toast.makeText(this@OverlayService, "API key সেট করুন (Main screen)", Toast.LENGTH_LONG).show()
                        tts?.speak("API কী সেট করুন", TextToSpeech.QUEUE_FLUSH, null, "nokey")
                        return@launch
                    }

                    val turns = MemoryStore.load(this@OverlayService).map { it.role to it.content }

                    val reply = withContext(Dispatchers.IO) {
                        OpenAIClient.respond(
                            apiKey = apiKey,
                            model = "gpt-4o-mini",
                            system = "You are a friendly Bengali voice assistant. Reply in Bangla, short and helpful.",
                            turns = turns
                        )
                    }

                    MemoryStore.append(this@OverlayService, "assistant", reply)
                    Toast.makeText(this@OverlayService, reply, Toast.LENGTH_LONG).show()
                    tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")
                }
                }
            },
            onError = {
                Toast.makeText(this, "শুনতে পারিনি। আবার tap করুন।", Toast.LENGTH_SHORT).show()
            }
        ))

        try {
            speech?.startListening(intent)
        } catch (_: Throwable) {
            Toast.makeText(this, "Mic permission দিন (RECORD_AUDIO)", Toast.LENGTH_SHORT).show()
        }
    }
}
