package com.error.girlai.net

import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

object OpenAITtsClient {
    fun speakToFile(apiKey: String, text: String, outFile: File, voice: String = "alloy") {
        val json = JSONObject()
            .put("model", "gpt-4o-mini-tts")
            .put("voice", voice)
            .put("format", "mp3")
            .put("input", text)
            .toString()

        val resp = Http.postJson(
            url = "https://api.openai.com/v1/audio/speech",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            json = json
        )

        resp.use {
            val bytes = it.body?.bytes() ?: ByteArray(0)
            if (!it.isSuccessful) throw RuntimeException("TTS failed: ${it.code} ${String(bytes)}")
            FileOutputStream(outFile).use { fos -> fos.write(bytes) }
        }
    }
}
