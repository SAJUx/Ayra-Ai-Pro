package com.error.girlai.net

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Uses OpenAI Responses API.
 * Docs: https://platform.openai.com/docs/api-reference/responses
 */
object OpenAIClient {
    private val http = OkHttpClient()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    /**
     * NOTE: For production, do NOT ship your API key in the app.
     * Use a backend proxy.
     */
    fun respond(
        apiKey: String,
        model: String,
        system: String,
        turns: List<Pair<String, String>> // (role, content)
    ): String {
        val input = JSONArray()

        input.put(JSONObject().apply {
            put("role", "system")
            put("content", system)
        })

        turns.forEach { (role, content) ->
            input.put(JSONObject().apply {
                put("role", role)
                put("content", content)
            })
        }

        val payload = JSONObject().apply {
            put("model", model)
            put("input", input)
            put("text", JSONObject().apply { put("format", "text") })
        }

        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer " + apiKey)
            .post(payload.toString().toRequestBody(JSON))
            .build()

        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return "API error: " + resp.code + " " + resp.message
            }

            val root = JSONObject(body)
            val output = root.optJSONArray("output") ?: return "No output"

            for (i in 0 until output.length()) {
                val item = output.getJSONObject(i)
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val c = content.getJSONObject(j)
                    if (c.optString("type") == "output_text") {
                        return c.optString("text")
                    }
                }
            }
            return "No text output"
        }
    }
}
