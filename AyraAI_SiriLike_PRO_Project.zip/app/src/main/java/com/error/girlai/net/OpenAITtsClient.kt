package com.error.girlai.net

import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

object OpenAITtsClient {
    fun speakToFile(apiKey: String, text: String, outFile: File, voice: String = "alloy") {
        val json = JSONObject()
            .put("model", "gpt-4o-mini-tts")
            .put("voice", voice)
            .put("format", "mp3")
            .put("input", text)
            .toString()

        Http.postJson(
            url = "https://api.openai.com/v1/audio/speech",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            json = json
        ).use { resp ->
            val bytes = resp.body?.bytes() ?: ByteArray(0)
            if (!resp.isSuccessful) throw RuntimeException("TTS failed: ${resp.code} ${String(bytes)}")
            FileOutputStream(outFile).use { it.write(bytes) }
        }
    }
}
