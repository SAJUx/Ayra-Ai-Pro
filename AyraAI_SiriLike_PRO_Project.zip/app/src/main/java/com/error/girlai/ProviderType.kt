package com.error.girlai

enum class ProviderType { OPENAI, GEMINI }
